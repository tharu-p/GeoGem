import sqlite3

def connection():
    return sqlite3.connect("localbiz.db")

def setup_tables():
    conn = connection()
    cursor = conn.cursor()

    # USERS TABLE
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        email TEXT,
        password TEXT,
        points INTEGER DEFAULT 0
    )
    """)

    # BUSINESSES TABLE
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS businesses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE,
        email TEXT,
        password TEXT,
        address TEXT,
        category TEXT,
        main_image TEXT,
        description TEXT,
        promo_text TEXT,
        phone TEXT,
        website TEXT,
        facebook TEXT,
        instagram TEXT,
        twitter TEXT,
        employees INTEGER,
        annual_revenue INTEGER,
        local_spending INTEGER,
        years_active INTEGER
    )
    """)

    # RATINGS TABLE
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ratings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        email TEXT,
        business TEXT,
        stars INTEGER,
        description TEXT
    )
    """)

    # FAVOURITES TABLE
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS favourites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        business_id INTEGER
    )
    """)

    # REDEMPTIONS TABLE (for reward codes)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS redemptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE,
        username TEXT,
        business_id INTEGER,
        used INTEGER DEFAULT 0,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # View Log (for points)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS view_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    business_id INTEGER,
    date TEXT
)
""")

    conn.commit()
    conn.close()


def get_businesses(search, category):
    conn = connection()
    cursor = conn.cursor()

    query = "SELECT * FROM businesses WHERE 1=1"
    params = []

    if search:
        query += " AND name LIKE ?"
        params.append(f"%{search}%")

    if category:
        query += " AND category = ?"
        params.append(category)

    cursor.execute(query, params)
    results = cursor.fetchall()
    conn.close()
    return results


def rating_input_data(username, email, business, stars, description):
    conn = connection()
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO ratings (username, email, business, stars, description)
    VALUES (?, ?, ?, ?, ?)
    """, (username, email, business, stars, description))

    conn.commit()
    conn.close()


def user_input_data(name, ema, passw):
    conn = connection()
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO users (username, email, password)
    VALUES (?, ?, ?)
    """, (name, ema, passw))

    conn.commit()
    conn.close()


def business_input_data(name, ema, passw, addy, category,
                        main_image=None, description=None, promo_text=None,
                        phone=None, website=None, facebook=None,
                        instagram=None, twitter=None,
                        employees=None, annual_revenue=None, local_spending=None, years_active=None):

    conn = connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
        INSERT INTO businesses 
        (name, email, password, address, category, main_image, description, promo_text, phone, website, facebook, instagram, twitter,
         employees, annual_revenue, local_spending, years_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (name, ema, passw, addy, category, main_image, description, promo_text,
              phone, website, facebook, instagram, twitter,
              employees, annual_revenue, local_spending, years_active))

        conn.commit()
        conn.close()
        return True

    except sqlite3.IntegrityError:
        conn.close()
        return False


def get_latest_user(typing):
    conn = connection()
    cursor = conn.cursor()

    if typing == "business":
        cursor.execute("SELECT name, email FROM businesses ORDER BY id DESC LIMIT 1")
    elif typing == "user":
        cursor.execute("SELECT username, email FROM users ORDER BY id DESC LIMIT 1")

    result = cursor.fetchone()
    conn.close()
    return result


def get_all_users(typing):
    conn = connection()
    cursor = conn.cursor()

    if typing == "users":
        cursor.execute("SELECT id, username, email, password FROM users")
    elif typing == "businesses":
        cursor.execute("SELECT id, name, email, password, address, category, employees, annual_revenue, local_spending, years_active FROM businesses")

    rows = cursor.fetchall()
    conn.close()
    return rows


def get_user_by_email(email):
    conn = connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
    result = cursor.fetchone()

    conn.close()
    return result

def get_all_codes():
    conn = connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, code, username, business_id, used, timestamp
        FROM redemptions
        ORDER BY timestamp DESC
    """)

    codes = cursor.fetchall()
    conn.close()
    return codes