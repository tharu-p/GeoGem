# importing all the necessary libraries 
import secrets 
import requests
import random
import string
import datetime   # NEW: needed for anti-abuse date tracking
from flask import Flask, render_template, request, session, redirect, url_for, jsonify
from db import connection, setup_tables, user_input_data, get_user_by_email, get_all_users, business_input_data, get_businesses, rating_input_data, get_all_codes

def generate_code():
    code = ""
    for letter in range(6):
        code += random.choice(string.ascii_uppercase)
    return code

# need to add proper comments for functions

setup_tables()

SECRET_KEY = "6Ldm3XUsAAAAANvnHVlUTR7QMI8J_tTAriQLFlq-"

app = Flask(__name__)

app.secret_key = secrets.token_hex(16)

# defining a function to use llama to create a response for the user 
def ask_ai(prompt):
    response = requests.post(
        "http://localhost:11434/api/generate",
        json={
            "model": "llama3.2:1b",
            "prompt": prompt,
            "stream": False,
            "num_predict": 60,
            "temperature": 0,
        }
    )
    
    return response.json()["response"]

ask_ai("warmup")

# if you ever have to delete some businesses, replace the id with the one in admin page
'''
import sqlite3
conn = sqlite3.connect("localbiz.db")
cursor = conn.cursor()
cursor.execute("DELETE FROM businesses WHERE id = 3")
conn.commit()
conn.close()
'''

@app.route("/", methods=["GET"])
def home():
    return render_template("index.html")

@app.route("/api/ask", methods=["POST"])
def api_ask():
    data = request.get_json()
    user_question = data.get("question", "")

    # get all businesses
    businesses = get_businesses("", "")
    
    # convert to readable text
    business_list = ""
    for b in businesses:
        business_list += f"{b[1]} — category: {b[5]}, address: {b[4]}\n"

    pre_prompt = f"""
You are GeoGem AI — a friendly assistant that helps users discover local businesses 
and understand the economic impact of shopping locally.

Here is a list of local businesses you can recommend:
{business_list}

Your responsibilities:
1. Recommend businesses based on user needs.
2. Explain how supporting small businesses helps the local economy.
3. Help users navigate the platform.
4. Keep answers short and friendly.
5. No formatting symbols.

"""

    answer = ask_ai(pre_prompt + user_question)
    return jsonify({"answer": answer})

# simply clicking the button ends the user session
@app.route("/logout") 
def logout(): 
    session.clear() 
    return render_template("index.html")

# the discover page which shows all the available businesses 
# the discover page which shows all the available businesses 
@app.route("/discover", methods=["GET"])
def discover():
    search = request.args.get("search", "").strip()
    category = request.args.get("category", "").strip()

    # NEW: rating filter and sorting
    sort = request.args.get("sort", "").strip()
    min_rating = request.args.get("min_rating", "").strip()

    businesses = get_businesses(search, category)

    # favourite feature to allow easy access to the business's page 
    username = session.get("user_name")
    conn = connection()
    cursor = conn.cursor()
    cursor.execute("SELECT business_id FROM favourites WHERE username = ?", (username,))
    fav_ids = {row[0] for row in cursor.fetchall()}

    # NEW: compute average rating for each business
    businesses_with_ratings = []
    for b in businesses:
        biz_id = b[0]
        cursor.execute("SELECT AVG(stars) FROM ratings WHERE business = ?", (b[1],))
        avg_rating = cursor.fetchone()[0]
        avg_rating = round(avg_rating, 2) if avg_rating else 0
        businesses_with_ratings.append((b, avg_rating))

    # filter by minimum rating
    if min_rating:
        try:
            min_r = float(min_rating)
            businesses_with_ratings = [item for item in businesses_with_ratings if item[1] >= min_r]
        except:
            pass

    # sorting by rating
    if sort == "high":
        businesses_with_ratings.sort(key=lambda x: x[1], reverse=True)
    elif sort == "low":
        businesses_with_ratings.sort(key=lambda x: x[1])

    conn.close()

    # pass updated structure to template
    return render_template("discover.html", businesses=businesses_with_ratings, fav_ids=fav_ids)

@app.route("/select")
def select():
    return render_template("select.html")

@app.route("/business", methods=["GET", "POST"])
def business():
    if request.method == "POST":
        # basic information about business
        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]
        address = request.form["address"]
        category = request.form["category"]

        # business page information
        main_image = request.form.get("main_image")
        description = request.form.get("description")
        promo_text = request.form.get("promo_text")
        phone = request.form.get("phone")
        website = request.form.get("website")
        facebook = request.form.get("facebook")
        instagram = request.form.get("instagram")
        twitter = request.form.get("twitter")

        # economical information 
        employees = request.form.get("employees")
        annual_revenue = request.form.get("annual_revenue")
        local_spending = request.form.get("local_spending")
        years_active = request.form.get("years_active")

        success = business_input_data(
            name, email, password, address, category,
            main_image, description, promo_text,
            phone, website, facebook, instagram, twitter,
            employees, annual_revenue, local_spending, years_active
        )

        if success == False:
            return render_template("business.html", error="Business name already taken.")
        else: 
            session["user_name"] = name
            return render_template("index.html")

    return render_template("business.html")

@app.route("/rate/<int:biz_id>", methods=["POST"])
def rate(biz_id):
    if "user_name" not in session:
        return redirect("/login")

    username = session["user_name"]
    stars = request.form["stars"]
    comment = request.form["comment"]

    conn = connection()
    cursor = conn.cursor()

    cursor.execute("SELECT name FROM businesses WHERE id = ?", (biz_id,))
    business_name = cursor.fetchone()[0]

    rating_input_data(username, username + "@placeholder.com", business_name, stars, comment)

    # NEW: award +10 points for rating a business
    cursor.execute("UPDATE users SET points = points + 10 WHERE username = ?", (username,))
    conn.commit()

    conn.close()

    return redirect(f"/business/{biz_id}")

@app.route("/rating", methods=["GET", "POST"])
def rating():
    if request.method == "POST":
        username = request.form["name"]
        email = request.form["email"]
        business = request.form["business"]
        stars = request.form["stars"]
        description = request.form["description"]

        rating_input_data(username, email, business, stars, description)

        return render_template("rating.html")

    return render_template("business.html")

@app.route("/admin") 
def admin(): 
    if session.get("user_name") != "admin_login":
        return redirect("/login")
    else:
        all_users = get_all_users("users")
        all_businesses = get_all_users("businesses")
        all_codes = get_all_codes()
        return render_template("admin.html", users=all_users, businesses=all_businesses, codes=all_codes)

@app.route("/favourites")
def favourites():
    if "user_name" not in session:
        return redirect("/login")
    username = session["user_name"]
    conn = connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT b.*
        FROM businesses b
        JOIN favourites f ON b.id = f.business_id
        WHERE f.username = ?
    """, (username,))

    favs = cursor.fetchall()
    conn.close()

    return render_template("favourites.html", favourites=favs)

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        recaptcha_token = request.form.get("g-recaptcha-response")
        
        if not recaptcha_token: 
            return render_template("signup.html", result="reCAPTCHA token missing")

        verify_url = "https://www.google.com/recaptcha/api/siteverify"
        payload = {
            "secret": SECRET_KEY, 
            "response": recaptcha_token 
        }
        response = requests.post(verify_url, data=payload) 
        result = response.json()

        if not result.get("success"):
            return render_template("signup.html", result="reCAPTCHA failed — please try again")

        username = request.form["name"]
        email = request.form["email"]
        password = request.form["password"] 

        session["user_name"] = username 
        user_input_data(username, email, password)

        return render_template("index.html")
    else:
        return render_template("signup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    error = ""

    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        user = get_user_by_email(email)
        if user is None: 
            error = "Email not found."
        else:
            stored_password = user[3]
            if password == stored_password:
                session["user_name"] = user[1] 
                return render_template("index.html")
            else: 
                error = "Incorrect password."

    return render_template("login.html", error=error)

@app.route("/toggle_favorite", methods=["POST"])
def toggle_favorite():
    if "user_name" not in session:
        return redirect("/login")

    username = session["user_name"]
    biz_id = request.form["biz_id"]

    conn = connection()
    cursor = conn.cursor()

    cursor.execute("SELECT id FROM favourites WHERE username = ? AND business_id = ?", (username, biz_id))
    existing = cursor.fetchone()
    if existing:
        cursor.execute("DELETE FROM favourites WHERE username = ? AND business_id = ?", (username, biz_id))
    else:
        cursor.execute("INSERT INTO favourites (username, business_id) VALUES (?, ?)", (username, biz_id))

        # NEW: award +5 points for adding a favourite
        cursor.execute("UPDATE users SET points = points + 5 WHERE username = ?", (username,))

    conn.commit()
    conn.close()

    return redirect(request.referrer)

@app.route("/business/<int:biz_id>")
def business_page(biz_id):
    conn = connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM businesses WHERE id = ?", (biz_id,))
    business = cursor.fetchone()

    if not business:
        conn.close()
        return "Business not found", 404

    cursor.execute("""
        SELECT * FROM ratings
        WHERE business = ?
        ORDER BY id DESC
    """, (business[1],))

    reviews = cursor.fetchall()
    conn.close()

    # NEW: award +1 point for viewing a business (once per business per day)
    if "user_name" in session:
        username = session["user_name"]
        today = datetime.date.today().isoformat()

        conn = connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id FROM view_log
            WHERE username = ? AND business_id = ? AND date = ?
        """, (username, biz_id, today))

        already_viewed = cursor.fetchone()

        if not already_viewed:
            cursor.execute("UPDATE users SET points = points + 1 WHERE username = ?", (username,))
            cursor.execute("INSERT INTO view_log (username, business_id, date) VALUES (?, ?, ?)",
                           (username, biz_id, today))
            conn.commit()

        conn.close()

    # AI summary generation using database information
    prompt = f"""
    Write a concise, friendly business description for a local business. Explain how supporting this business helps the local economy.  Include how an individual customer’s purchase contributes to jobs, local spending, and community growth.  Avoid formatting symbols like asterisks or slashes. DO NOT WRITE ANYTHING ELSE EXCEPT FOR DESCRIPTION
    Business Name: {business[1]}
    Category: {business[5]}
    Address: {business[4]}
    Description: {business[7] or "No description provided"}
    Employees: {business[14] or "Unknown"}
    Annual Revenue: {business[15] or "Unknown"}
    Local Spending: {business[16] or "Unknown"}
    Years Active: {business[17] or "Unknown"}
    """

    ai_summary = ask_ai(prompt)

    return render_template("business_page.html", business=business, reviews=reviews, ai_summary=ai_summary)

@app.route("/points")
def points():
    if "user_name" not in session:
        return redirect("/login")

    username = session["user_name"]

    conn = connection()
    cursor = conn.cursor()
    cursor.execute("SELECT points FROM users WHERE username = ?", (username,))
    user_points = cursor.fetchone()[0]
    conn.close()

    return render_template("points.html", points=user_points)

@app.route("/verify", methods=["GET", "POST"])
def verify():
    message = ""

    if request.method == "POST":
        code = request.form["code"].strip().upper()

        conn = connection()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM redemptions WHERE code = ?", (code,))
        record = cursor.fetchone()

        if not record:
            message = "Invalid code."
        elif record[4] == 1:
            message = "This code has already been used."
        else:
            cursor.execute("UPDATE redemptions SET used = 1 WHERE code = ?", (code,))
            conn.commit()
            message = "Code verified successfully!"
        conn.close()
    return render_template("verify.html", message=message)

@app.route("/redeem", methods=["POST"])
def redeem():
    if "user_name" not in session:
        return redirect("/login")

    username = session["user_name"]

    conn = connection()
    cursor = conn.cursor()

    # get current points
    cursor.execute("SELECT points FROM users WHERE username = ?", (username,))
    result = cursor.fetchone()

    if not result:
        conn.close()
        return jsonify({"error": "User not found"}), 404
    current_points = result[0]

    # check if user has enough points
    if current_points < 250 and session.get("user_name") != "admin_login":
        conn.close()
        return jsonify({"error": "Not enough points"}), 400

    # deduct points
    new_points = current_points - 250
    cursor.execute("UPDATE users SET points = ? WHERE username = ?", (new_points, username))

    # generate code
    code = generate_code()

    # store code in redemptions table
    cursor.execute("""
        INSERT INTO redemptions (code, username, used)
        VALUES (?, ?, 0)
    """, (code, username))

    conn.commit()
    conn.close()

    return jsonify({"code": code, "remaining_points": new_points})

if __name__ == "__main__":
    app.run(debug=True)